﻿namespace suicide.framework.StaticMethods;

public static class UArray
{
    
}